# Elevator Safety Equipment Market — Dataset

This dataset contains structured metadata and derived summaries from the public landing page of the *Elevator Safety Equipment Market (CM3567)* report by Next Move Strategy Consulting.

It includes:
- metadata.json  
- summary.txt  
- segments.csv  
- companies.csv  
- table_of_contents.md  
- license.txt

This dataset **does not** include paid content from the full report. Only public information is reorganized into research-friendly files.
